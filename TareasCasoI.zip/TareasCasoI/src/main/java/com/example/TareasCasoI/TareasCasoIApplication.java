package com.example.TareasCasoI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TareasCasoIApplication {

	public static void main(String[] args) {
		SpringApplication.run(TareasCasoIApplication.class, args);
	}

}
