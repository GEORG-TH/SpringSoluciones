package com.example.TareasCasoI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TareasCasoIApplicationTests {

	@Test
	void contextLoads() {
	}

}
